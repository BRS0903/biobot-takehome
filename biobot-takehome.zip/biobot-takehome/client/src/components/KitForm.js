import React, {useState} from 'react'
import { getKit } from '../apis/apis';

const KitForm = ({ resultKit, setResultKit }) => {
  const [labelId, setLabelId] = useState("");
  const [suggestions, setSuggestions] = useState([])
  const handleLabelId = (e) => {
    setLabelId(e.target.value);
    getKit(e.target.value).then((data) => {
      setResultKit(data);
      if(Array.isArray(data)) setSuggestions(data);
    });
  };
  const handleSuggestion = (label_id) => {
    setLabelId(label_id);
    setSuggestions([])
    getKit(label_id).then((data) => {
      setResultKit(data);
    });
  };
  const suggestionsList = suggestions.map(({ id, label_id }) => (
    <div key={id} onClick={() => handleSuggestion(label_id)}>
      {label_id}
    </div>
  ));

  return (
    <form>
      <input
        type="text"
        placeholder="Search By label id"
        value={labelId}
        onChange={handleLabelId}
      />
      <div className="suggestions">{suggestionsList}</div>
    </form>
  );
};

export default KitForm
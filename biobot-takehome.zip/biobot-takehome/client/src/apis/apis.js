export const getKit = async (label_id) => {
  try {
    const result = await fetch(
      `http://localhost:5050/api/kit?label_id=${label_id}`,
      {
        method: "GET",
        headers: { "Content-Type": "application/json" },
      }
    );
    return await result.json()
  } catch (err) {
      throw new Error(err)
  }
};

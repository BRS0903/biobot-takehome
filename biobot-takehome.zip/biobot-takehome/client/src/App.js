import React, {useState} from 'react'
import KitForm from './components/KitForm'
import './App.css'

const App = () => {
    const [resultKit, setResultKit] = useState({})
  return (
    <div className="container">
      <KitForm resultKit={resultKit} setResultKit={setResultKit} />
      <div>shipping tracking code: {resultKit[0]?.shipping_tracking_code}</div>
    </div>
  );
}

export default App
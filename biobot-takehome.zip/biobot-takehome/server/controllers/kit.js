const fs = require("fs");
module.exports = {
  getKit: (req, res, next) => {
    const { label_id } = req.query;
    let rawdata = fs.readFileSync("KITS_SHIPPING_DATA.json");
    let kits = JSON.parse(rawdata).kits;
    if(!label_id) res.json({message : 'this id is not exist'})
    const kit = kits.filter((kit) => kit.label_id.startsWith(label_id));
    return res.json(kit ? kit : { message: "this id is not exist" });
  },
};

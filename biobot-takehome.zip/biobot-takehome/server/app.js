const express = require("express");
const cors = require("cors");
const PORT = 5050;

const app = express();

// routes
const kitRouter = require("./routes/kit");

//config
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: false }));

app.get("/", (req, res) => {
  return res.send("Welcome to Kits API");
});

app.use("/api/kit", kitRouter);

app.listen(PORT, () => console.log(`running at http://localhost:${PORT}`));

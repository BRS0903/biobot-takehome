const router = require("express").Router();
const kitController = require('../controllers/kit')

router.get("/", kitController.getKit);

module.exports = router;
